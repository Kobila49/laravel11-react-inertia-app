export const PROJECT_STATUS_CLASS_MAP = {
  pending: "bg-amber-500",
  in_progress: "bg-blue-500 ",
  completed: "bg-green-500",
};
export const PROJECT_STATUS_TEXT_MAP = {
  pending: "Pending",
  in_progress: "In Progress",
  completed: "Completed",
};
export const TASK_STATUS_CLASS_MAP: Record<"pending" | "in_progress" | "completed", string> = {
  pending: "bg-yellow-500",
  in_progress: "bg-blue-500",
  completed: "bg-green-500",
};

export const TASK_STATUS_TEXT_MAP: Record<"pending" | "in_progress" | "completed", string> = {
  pending: "Pending",
  in_progress: "In Progress",
  completed: "Completed",
};

export const TASK_PRIORITY_CLASS_MAP = {
  low: "bg-gray-600",
  medium: "bg-amber-600",
  high: "bg-red-600",
};
export const TASK_PRIORITY_TEXT_MAP = {
  low: "Low",
  medium: "Medium",
  high: "High",
};

export const USER_STATUS_CLASS_MAP: { [key in 'active' | 'inactive']: string } = {
  active: "bg-green-500",
  inactive: "bg-red-500",
};

export const USER_STATUS_TEXT_MAP: { [key in 'active' | 'inactive']: string } = {
  active: "Active",
  inactive: "Inactive",
};
